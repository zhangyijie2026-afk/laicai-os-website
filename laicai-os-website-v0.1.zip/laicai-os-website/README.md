# Laicai OS Website

Laicai OS official website foundation.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000
